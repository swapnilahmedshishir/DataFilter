async function loadApp() {
     await import('./index.js');
}
loadApp();